<!DOCTYPE html>
<html>
<head>
    <title>Jitsi Meeting</title>
</head>
<body>
    <iframe src="{{ $meetingLink }}" width="100%" height="600px" allow="camera; microphone; fullscreen"></iframe>
</body>
</html>
