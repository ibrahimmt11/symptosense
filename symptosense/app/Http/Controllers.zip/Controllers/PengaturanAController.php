<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PengaturanAController extends Controller
{
    public function pengaturanA()
    {
        return view('Admin/pengaturanA');
    }
}
