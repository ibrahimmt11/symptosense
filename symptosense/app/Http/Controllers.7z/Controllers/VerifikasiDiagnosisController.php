<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Models\Diagnosis;
use App\Models\Pasien;
use App\Models\Dokter;
use Illuminate\Support\Facades\Auth;

class VerifikasiDiagnosisController extends Controller
{
    public function verifikasiDiagnosis()
    {
        // Fetch the authenticated doctor's ID
        $userId = Auth::id();
        $dokterId = DB::table('dokter')->where('user_id', $userId)->value('id_dokter');

        // Fetch the doctor's data
        $dokter = Dokter::find($dokterId); 
        $consultations = DB::table('diagnosis')
            ->join('pasien', 'diagnosis.id_pasien', '=', 'pasien.id_pasien')
            ->join('dokter', 'diagnosis.id_dokter', '=', 'dokter.id_dokter')
            ->select(
                'pasien.nama_lengkap',
                'diagnosis.id_diagnosis',
                'diagnosis.hasil_diagnosis',
                'diagnosis.dokumen as diagnosis_dokter',
                'diagnosis.gejala_terpilih'
            )
            ->get();
            // ->map(function($item) {
            //     $item->gejala_terpilih = json_decode($item->gejala_terpilih);
            //     return $item;
            // });

        return view('Dokter.verifikasiDiagnosis', compact('consultations', 'dokter'));
    }

    public function update(Request $request, string $id_diagnosis){
        $dataVerif = verifikasiDiagnosis::find($id_diagnosis);

        $request->validate([
            'keterangan' => 'required'
        ]);

        verifikasiDiagnosis::where('id_diagnosis', $dataVerif->id_diagnosis)->update([
            'keterangan' => $request['keterangan']
        ]);

        return redirect('/diagnosisP');
    }

    public function saveConsultation(Request $request)
    {
        $validatedData = $request->validate([
            'id_dokter' => 'required|integer',
            'id_diagnosis' => 'required|integer',
        ]);

        $userId = Auth::id();
        $pasienId = DB::table('pasien')->where('user_id', $userId)->value('id_pasien');

        try {
            Konsultasi::create([
                'id_dokter' => $validatedData['id_dokter'],
                'id_pasien' => $pasienId,
                'id_diagnosis' => $validatedData['id_diagnosis'],
                'hasil_konsul' => '',
                'status' => 'Scheduled',
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            return response()->json(['success' => true]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }
}
